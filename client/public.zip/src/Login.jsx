import React, { Component, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
function LoginForm() { 
  const[email,setemail]=useState()
  const[password,setpassword]=useState()
  const navigate=useNavigate()
  const handleSub=(e)=>{
    e.preventDefault()
    axios.post('http://localhost:3001/login',{email,password})
    .then(res=>{
      console.log(res)
      if(res.data==="Sucess"){
  
      
        navigate('/todo')
      
      }
      if(res.data=="incorrect password"){
        alert("Incorrect password");
      }
      else if(res.data=="no record exists"){
        alert("No record Exists")
      }
    })
    .catch(err=>console.log(err))
  }

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleSub}>
        <div>
          <label>Email:</label>
          <input type="email" name="email" onChange={(e)=>setemail(e.target.value)}/>
        </div>
        <div>
          <label>Password:</label>
          <input type="password" name="password" onChange={(e)=>setpassword(e.target.value)}/>
        </div>
        <button type="submit">Login</button>
      </form>
    </div>
  );
}
export default LoginForm;


