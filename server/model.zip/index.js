const express=require('express')
const mongoose=require('mongoose')
const cors=require('cors')
const jwt=require('jsonwebtoken')
//const session = require('express-session');
const cookieParser = require('cookie-parser')
const usermodel=require('./model/userdata')
const todoModel=require('./model/todolist')
const app=express()
app.use(express.json())
app.use(cookieParser())
app.use(cors({
    //origin: ["http://localhost:3001"],
    methods: ["GET", "POST","PUT" ,"DELETE"],
    credentials: true

}))


/* app.use(session({
  secret: 'nehapanwal02',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 3600000 } // Set the session timeout in milliseconds
})); */
mongoose.connect('mongodb://127.0.0.1:27017/userdata',{
    useNewUrlParser: true,
    useUnifiedTopology: true
})
const authenticate=async(req,res,next)=>{
    const token=req.cookies.jwt;
    if(!token){
        return res.status(401).json({error:"Token missing"})

    }
    try{
        const userdata=await jwt.verify(token,"thisisamernstackprojectabcdefghijklmnopqrstuvwxyz")
        console.log("userdata")
        req.userdata=userdata;
        next();

    }
    catch(err){
        return res.status(401).json({error:"Invalid Token"})
    }
}

app.post('/register',async(req,res)=>{
    const {user,email,password}=req.body
    const user1=await usermodel.findOne({email:email})
    if(!user1){
        const newUser=new todoModel({
            useremail:email,
            todos: [],
        })
        newUser.save()  
            .then(data => res.json(data))
            .catch(err1 => console.log(err1));
        usermodel.create(req.body)
        .then(data=>console.log(res.json(data)))
        .catch(err1=>console.log(err1))

    }
    else{
        res.json("email already registered")
    }
})
app.post('/login',async(req,res)=>{
    const {email,password}=req.body
    //res.cookie("neha","qqqqqqqq")
    //req.session.userId = email
    
    try{
        const user=await usermodel.findOne({email: email})
        if(user){
            if(user.password===password){
                const token=await user.generateAuthToken()
                console.log(token)
                res.cookie("jwt",token,{
                    expires: new Date(Date.now() + 60000000),
                    httpOnly: true
                })
                console.log(req.cookies.jwt)
                res.json("Sucess")  
                 
            }
            else{
                res.json("incorrect password")
            }
        }
        else{
            res.json("No recod exists")
        }
    }
    catch(error){
        console.log(error)
    }
})
app.post('/add',authenticate, async (req, res) => {
    const task = req.body.task;
    const token = req.cookies.jwt
    //console.log(res.headers.getSetCookie())
    //console.log(req.cookies.jwt)
    //console.log(`the secret key is ${req.cookies.jwt}`);
    if (!token) {
        return res.status(501).json({ error: 'Token missing' });
    } 
    const tempuser=await jwt.verify(token,'thisisamernstackprojectabcdefghijklmnopqrstuvwxyz')
    console.log(tempuser)

    try {
        const user = await todoModel.findOne({ useremail: tempuser.email })
        if (!user) {
            return res.status(404).json({ error: "User not found" });
        }
        else{
            user.todos.push({ task, done: false }); 
            const result = await user.save();
            res.json(result);
            
        }
       
    } catch (err) {
        console.log(err);
    }
});
app.get('/Secret',(req,res)=>{
    //console.log(`the secret key is ${req.cookies.jwt}`);
    res.render("secret")
})

app.get('/Get',(req,res)=>{
    todoModel.find()
    .then(result=>res.json(result))
    .catch(err=>res.json(err))
})
   app.get('/logout',(req,res)=>{
    //req.session.destroy((err)=>{
        if(err){
            res.json("error destroying session")
        }
        else{
            res.json ("sucess")
        }
    //})
}) 
app.put('/update/:id',(req,res)=>{
    const {id}=req.params;
    todoModel.findByIdAndUpdate({_id: id},{done :true})
    .then(result=>res.json(result))
    .catch(err=>res.json(err))
    console.log(id);
})
app.delete('/delete/:id',(req,res)=>{
    const {id}=req.params;
    todoModel.findByIdAndDelete({_id:id})
    .then(result=>res.json(result))
    .catch(err=>res.json(err))
    
})
app.listen(3001,()=>{console.log("server is listening")})